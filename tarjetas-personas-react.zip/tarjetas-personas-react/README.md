# Tarjetas de personas con React

Aplicación de React que presenta cinco tarjetas con nombre, ocupación y país. Los datos se pasan del componente padre (`App.jsx`) al componente hijo (`PersonaCard.jsx`) mediante `props`.

## Requisitos de la tarea

- [x] Componente padre que envía los datos.
- [x] Lista inicial de cinco personas.
- [x] Cada tarjeta muestra nombre, ocupación y país.
- [x] Estilos CSS y diseño adaptable.
- [x] Arreglo de objetos en el componente padre.
- [x] `map()` crea un componente hijo por persona.
- [x] `useEffect` inicializa la lista.
- [x] `props` pasan los datos del padre al hijo.

## Cómo ejecutar el proyecto

Necesitas tener instalado Node.js.

1. Descomprime el archivo ZIP.
2. Abre una terminal dentro de la carpeta `tarjetas-personas-react`.
3. Ejecuta `npm install`.
4. Ejecuta `npm run dev`.
5. Abre en el navegador la dirección local que muestre Vite (normalmente `http://localhost:5173`).

Para comprobar la compilación de producción, ejecuta `npm run build`.

## Estructura

```text
tarjetas-personas-react/
├── index.html
├── package.json
├── README.md
└── src/
    ├── App.jsx
    ├── PersonaCard.jsx
    ├── main.jsx
    └── styles.css
```

## Explicación breve

- `App.jsx` es el componente padre. Declara el estado `personas`, carga los cinco objetos con `useEffect` y recorre el arreglo con `map()`.
- `PersonaCard.jsx` es el componente hijo. Recibe `nombre`, `ocupacion` y `pais` mediante `props` y los muestra en una tarjeta.
- `styles.css` define la apariencia de las tarjetas y adapta la cuadrícula a pantallas pequeñas.
