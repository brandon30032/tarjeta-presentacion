import { useEffect, useState } from "react";
import PersonaCard from "./PersonaCard.jsx";

export default function App() {
  const [personas, setPersonas] = useState([]);

  // useEffect inicializa el listado de personas cuando se monta el componente.
  useEffect(() => {
    const datosPersonas = [
      { id: 1, nombre: "Ana Martínez", ocupacion: "Diseñadora gráfica", pais: "Honduras" },
      { id: 2, nombre: "Carlos López", ocupacion: "Desarrollador web", pais: "México" },
      { id: 3, nombre: "Sofía García", ocupacion: "Doctora", pais: "España" },
      { id: 4, nombre: "Daniel Wilson", ocupacion: "Ingeniero civil", pais: "Estados Unidos" },
      { id: 5, nombre: "Valentina Rossi", ocupacion: "Chef", pais: "Italia" }
    ];

    setPersonas(datosPersonas);
  }, []);

  return (
    <main className="contenedor">
      <header className="encabezado">
        <p className="etiqueta">DIRECTORIO</p>
        <h1>Tarjetas de personas</h1>
        <p className="subtitulo">
          Ejemplo de componentes padre e hijo usando props en React.
        </p>
      </header>

      <section className="rejilla" aria-label="Lista de personas">
        {personas.map((persona) => (
          <PersonaCard
            key={persona.id}
            nombre={persona.nombre}
            ocupacion={persona.ocupacion}
            pais={persona.pais}
          />
        ))}
      </section>
    </main>
  );
}