export default function PersonaCard({ nombre, ocupacion, pais }) {
  return (
    <article className="tarjeta">
      <div className="avatar" aria-hidden="true">
        {nombre.charAt(0)}
      </div>
      <div className="datos">
        <h2>{nombre}</h2>
        <p><span>Ocupación</span>{ocupacion}</p>
        <p><span>País</span>{pais}</p>
      </div>
    </article>
  );
}